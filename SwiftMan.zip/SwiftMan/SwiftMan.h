//
//  SwiftMan.h
//  SwiftMan
//
//  Created by yangjun on 16/4/29.
//  Copyright © 2016年 yangjun. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftMan.
FOUNDATION_EXPORT double SwiftManVersionNumber;

//! Project version string for SwiftMan.
FOUNDATION_EXPORT const unsigned char SwiftManVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftMan/PublicHeader.h>


